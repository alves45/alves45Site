export default function (component, styles, scripts) {
  this.component = component;
  this.styles = styles;
  this.scripts = scripts;
}
