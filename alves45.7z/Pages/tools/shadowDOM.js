/**@type {Window} */
export default global.app.newWindow().window;
