import { css } from "@emotion/css";
import exportComponent from "../tools/exportComponent.js";
let aa = "";
export default function (label = "") {
  /**@type {Window} */
  let document = this.window.document;
  const inputTxt = document.createElement("div");
  const styleInputTxt = css`
    display: flex;
    flex-direction: column;
    label {
      height: 1rem;
      font-size: 1rem;
      order: 1;
      display: block;
      transform: translateY(1rem);
      z-index: -1;
      transition: ease-in-out 200ms;
      width: auto;
    }
    div {
      order: 3;
      transition: ease-in-out 200ms;
      transform: scaleX(0) translateY(-0.1rem);
      height: 0;
      border: 0;
      border-bottom: 0.1rem solid red;
    }
    input {
      height: 1.25rem;
      font-size: 1rem;
      order: 2;
      background-color: transparent;
      outline: none;
      border: 0;
      border-bottom: 0.1rem solid black;
    }
    input:not(:placeholder-shown) ~ label,
    input:focus ~ label {
      transform: scale(0.9) translate(-5.55%, 15%);
    }
    input:focus ~ div {
      transform: scaleX(1) translateY(-0.1rem);
    }
  `;
  inputTxt.innerHTML = `<div class="${styleInputTxt}">
  <input type="text" placeholder=" " required />
  <div></div>
  <label>${label || "Type something"}</label>
</div>
`;
  this.style.add(styleInputTxt);
  return new exportComponent(inputTxt);
}
