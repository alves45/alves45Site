import { css, cache, keyframes } from "@emotion/css";
import classStyle from "./tools/css.js";
import _inputTxt from "./components/inputTxt.js";
export default class {
  constructor(window) {
    /**@type {Window} */
    this.window = window;
    this.HTML = "";
    this.style = new classStyle(cache);
  }
  render = () => {
    let document = this.window.document;
    let inputTxt = _inputTxt.bind(this);
    if (process.env.NODE_ENV !== "production") {
      document.head.innerHTML += `<meta http-equiv="refresh" content="5" />`;
    }
    const styleDOM = document.createElement("style");
    this.style.addG(css`
      body {
        background-color: purple;
      }
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: Arial, Helvetica, sans-serif;
      }
      :root {
        font-size: min(10vh, 10vw);
      }
    `);
    document.body.appendChild(inputTxt("").component);
    styleDOM.innerHTML = this.style.buildStyles();
    document.head.appendChild(styleDOM);
    this.HTML = document.documentElement.innerHTML;
    console.log("page loaded");
  };
}
