import { css } from "@emotion/css";
let style = {};
style.add = css;

/**@type {import {"node_modules/@emotion/css/types/create-instance.d.ts"}.Emotion.css   */
style.add`
display: flex;
`;
